<template>
  <div>
    <h2>Role Management</h2>
  </div>
</template>

<script>
export default {
  name: 'RoleManagement'
};
</script>