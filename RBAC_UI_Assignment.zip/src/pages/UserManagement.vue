<template>
  <div>
    <h2>User Management</h2>
  </div>
</template>

<script>
export default {
  name: 'UserManagement'
};
</script>