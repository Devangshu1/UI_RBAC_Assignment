<template>
  <div>
    <h1>RBAC Dashboard</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App'
};
</script>