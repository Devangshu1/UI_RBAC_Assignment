export const mockApi = {
  getUsers: () => Promise.resolve([]),
  getRoles: () => Promise.resolve([]),
  addUser: (user) => Promise.resolve(user),
  addRole: (role) => Promise.resolve(role)
};