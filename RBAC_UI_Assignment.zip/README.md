# RBAC Dashboard

## Project Overview
This is a basic Role-Based Access Control (RBAC) dashboard with user and role management features.

### Features
- User Management
- Role Management
- Dynamic Permission Handling
- Mock API Simulation

### Setup
1. Clone the repository.
2. Install dependencies using `npm install`.
3. Run the project using `npm run serve`.

### Directory Structure
- `src/`: Source code
- `mock-api/`: Mock API responses

Enjoy!